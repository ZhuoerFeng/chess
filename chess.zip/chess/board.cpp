#include "board.h"
#include <QPoint>
#include <QString>
#include <QStringList>
#include <QDebug>
#include <QFileDialog>
#include <QFile>

Piece::Piece() {
    position = QPoint(-1, -1);
}

Piece::Piece(QString& name, QString& place) {
    if (name == "pawn") {
        type = PAWN;
    } else if (name == "rook") {
        type = ROOK;
    } else if (name == "knight") {
        type = KNIGHT;
    } else if (name == "bishop") {
        type = BISHOP;
    } else if (name == "queen") {
        type = QUEEN;
    } else if (name == "king") {
        type = KING;
    } else {
        qDebug() << "input piece error";
        type = NO_TYPE;
    }
    std::string temp = place.toStdString();
    if (temp[0] <= 'h' && temp[0] >= 'a' && temp[1] >= '1' && temp[1] <= '8') {
        int x = temp[0] - 'a' + 1;
        int y = temp[1] - '0';
        position = QPoint(x, y);
        qDebug() << position;
    }
}

Piece::~Piece() {
}


QVector<QPoint> Piece::get_access() {
    qDebug() << "in get access";
    auto isValid =[&](QPoint p) {
        if (p.x() >= 1 && p.x() <= 8 && p.y() >= 1 && p.y() <= 8) return true;
        qDebug() << "is invalid";
        return false;
    };
    auto hasSelf =[&](QPoint p) {
        if ((current_board->occupied[p.x()][p.y()] == true) && (current_board->board[p.x()][p.y()]->isWhite == isWhite) &&
                (current_board->board[p.x()][p.y()]->isEaten == false))
            return true;
        qDebug() << "has not self";
        return false;
    };
    auto hasOpposite =[&](QPoint p) {
        if ((current_board->occupied[p.x()][p.y()] == true) && (current_board->board[p.x()][p.y()]->isWhite != isWhite) &&
                (current_board->board[p.x()][p.y()]->isEaten == false))
            return true;
        qDebug() << "has not opposite";
        return false;
    };

    QVector<QPoint> access;
    QPoint current = position;
    if (type == ROOK) {
        qDebug() << current << "rook getting access";
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current + QPoint(dx, 0);
            if (isValid(temp) && !hasSelf(temp)) {
                qDebug() << " is accessibale";
                access.append(temp);
                if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current - QPoint(dx, 0);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dy=1; dy<= 7; ++dy) {
            QPoint temp = current + QPoint(0, dy);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dy=1; dy<= 7; ++dy) {
            QPoint temp = current - QPoint(0, dy);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
    } else if (type == BISHOP) {
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current + QPoint(dx, dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current - QPoint(dx, dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current + QPoint(dx, -dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current - QPoint(dx, -dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
    } else if (type == QUEEN) {
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current + QPoint(dx, 0);
            if (isValid(temp) && !hasSelf(temp)) {
                qDebug() << " is accessibale";
                access.append(temp);
                if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current - QPoint(dx, 0);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dy=1; dy<= 7; ++dy) {
            QPoint temp = current + QPoint(0, dy);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dy=1; dy<= 7; ++dy) {
            QPoint temp = current - QPoint(0, dy);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        //xiezou
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current + QPoint(dx, dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current - QPoint(dx, dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current + QPoint(dx, -dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
        for (int dx=1; dx<= 7; ++dx) {
            QPoint temp = current - QPoint(dx, -dx);
            if (isValid(temp) && !hasSelf(temp)) {
                    access.append(temp);
                    if (hasOpposite(temp)) break;
            } else break;
        }
    } else if (type == KNIGHT) {
        QPoint temp1 = current + QPoint(1, 2);
        if (isValid(temp1) && !hasSelf(temp1)) access.append(temp1);
        QPoint temp2 = current - QPoint(1, 2);
        if (isValid(temp2) && !hasSelf(temp2)) access.append(temp2);
        QPoint temp3 = current + QPoint(1, -2);
        if (isValid(temp3) && !hasSelf(temp3)) access.append(temp3);
        QPoint temp4 = current - QPoint(1, -2);
        if (isValid(temp4) && !hasSelf(temp4)) access.append(temp4);
        QPoint temp5 = current + QPoint(2, 1);
        if (isValid(temp5) && !hasSelf(temp5)) access.append(temp5);
        QPoint temp6 = current - QPoint(2, 1);
        if (isValid(temp6) && !hasSelf(temp6)) access.append(temp6);
        QPoint temp7 = current + QPoint(2, -1);
        if (isValid(temp7) && !hasSelf(temp7)) access.append(temp7);
        QPoint temp8 = current - QPoint(2, -1);
        if (isValid(temp8) && !hasSelf(temp8)) access.append(temp8);
    } else if (type == KING) {
        QPoint temp1 = current + QPoint(1, 1);
        if (isValid(temp1) && !hasSelf(temp1)) access.append(temp1);
        QPoint temp2 = current - QPoint(1, 1);
        if (isValid(temp2) && !hasSelf(temp2)) access.append(temp2);
        QPoint temp3 = current + QPoint(1, -1);
        if (isValid(temp3) && !hasSelf(temp3)) access.append(temp3);
        QPoint temp4 = current - QPoint(1, -1);
        if (isValid(temp4) && !hasSelf(temp4)) access.append(temp4);
        QPoint temp5 = current + QPoint(1, 0);
        if (isValid(temp5) && !hasSelf(temp5)) access.append(temp5);
        QPoint temp6 = current - QPoint(1, 0);
        if (isValid(temp6) && !hasSelf(temp6)) access.append(temp6);
        QPoint temp7 = current + QPoint(0, 1);
        if (isValid(temp7) && !hasSelf(temp7)) access.append(temp7);
        QPoint temp8 = current - QPoint(0, 1);
        if (isValid(temp8) && !hasSelf(temp8)) access.append(temp8);
    } else if (type == PAWN) {
        if (isWhite == true) {
            if (first_move == NO_MOVE) {
                QPoint temp1 = current + QPoint(0, 1);
                QPoint temp2 = current + QPoint(0, 2);
                if (isValid(temp1) && !hasSelf(temp1)) access.append(temp1);
                if (isValid(temp2) && !hasSelf(temp2)) access.append(temp2);
            } else {
                QPoint temp1 = current + QPoint(1, 1);
                QPoint temp2 = current + QPoint(-1, 1);

                QPoint temp3 = current + QPoint(0, 1);
                if (isValid(temp1) && hasOpposite(temp1)) access.append(temp1);
                if (isValid(temp1) && hasOpposite(temp2)) access.append(temp2);

                if (isValid(temp3) && !hasSelf(temp3)) access.append(temp3);
            }
        } else if (isWhite == false) {
            if (first_move == NO_MOVE) {
                QPoint temp1 = current + QPoint(0, -1);
                QPoint temp2 = current + QPoint(0, -2);
                if (isValid(temp1) && !hasSelf(temp1)) access.append(temp1);
                if (isValid(temp2) && !hasSelf(temp2)) access.append(temp2);
            } else {
                QPoint temp1 = current + QPoint(1, -1);
                QPoint temp2 = current + QPoint(-1, -1);

                QPoint temp3 = current + QPoint(0, -1);
                if (isValid(temp1) && hasOpposite(temp1)) access.append(temp1);
                if (isValid(temp1) && hasOpposite(temp2)) access.append(temp2);

                if (isValid(temp3) && !hasSelf(temp3)) access.append(temp3);
            }
        }

    }
    return access;
}

void Piece::do_command(QPoint target) {
    if (type == ROOK) {
        rook_command(target);
    }
}

bool Piece::straight_eat(QPoint target) {
    //无意义的操作
    if ((target.x() != position.x()) && (target.y() != position.y())) {
        return false;
    }
    qDebug() << "during straight eat...";
    if (type == QUEEN || type == ROOK) {
        qDebug() << "right type" << QString::number(type);
        if (target.x() == position.x() && (target.y() != position.y())) { // 同列
            qDebug() << "same column";
                if (target.y() > position.y()) { //上方
                    qDebug() << "eat up";
                    bool zhangai = false;
                    int i = position.y() + 1;
                    for (; i <= target.y() - 1; ++i) {
//                        qDebug() << i;
                        if (get_board()->occupied[position.x()][i]) {   //有障碍
                            zhangai = true;
                            break;
                        }
                    }

                    if (zhangai) return false;
                    get_board()->board[target.x()][target.y()]->isEaten = true;
                    get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                    get_board()->occupied[position.x()][position.y()] = false;
                    get_board()->occupied[target.x()][target.y()] = true;
                    get_board()->board[target.x()][target.y()]->position = target;
                } else if (target.y() < position.y()) {
                    qDebug() << "eat down";
                    bool zhangai = false;
                    int i = position.y() - 1;
                    for (; i >= target.y() + 1; --i) {
//                        qDebug() << i;
                        if (get_board()->occupied[position.x()][i]) {   //有障碍
                            zhangai = true;
                            break;
                        }
                    }
                    if (zhangai) return false;
                    get_board()->board[target.x()][target.y()]->isEaten = true;
                    get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                    get_board()->occupied[position.x()][position.y()] = false;
                    get_board()->occupied[target.x()][target.y()] = true;
                    get_board()->board[target.x()][target.y()]->position = target;
                }
        } else if (target.y() == position.y() && (target.x() != position.x())) { //同行
            qDebug() << "same row";
            if (target.x() > position.x()) { //右方
                qDebug() << "eat right";
                bool zhangai = false;
                int i = position.x() + 1;
                for (; i <= target.x() - 1; ++i) {
//                    qDebug() << i;
                    if (get_board()->occupied[i][position.y()]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()]->isEaten = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            } else if (target.x() < position.x()) { // 左方
                qDebug() << "eat left";
                bool zhangai = false;
                int i = position.x() - 1;
                for (; i >= target.x() + 1; --i) {
//                    qDebug() << i;
                    if (get_board()->occupied[i][position.y()]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()]->isEaten = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            }
        }
        return true;
    }
    return false; //为定义行为
}

bool Piece::diagonal_eat(QPoint target) {
    qDebug() << "during straight move...";
    if (type == BISHOP || type == QUEEN) {
        // 一三象限对角线
        if (target.x() - position.x() == target.y() - position.y()) {
            qDebug() << "Line I III";
            // 右上
            if (target.x() - position.x() > 0) {
                qDebug() << "right upper";
                bool zhangai = false;
                int i = 1;
                for (; i <= target.x() - position.x() - 1; ++i) {
                    if (get_board()->occupied[position.x() + i][position.y() + i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()]->isEaten = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            } else if (target.x() - position.x() < 0) {
                qDebug() << "left down";
                bool zhangai = false;
                int i = 1;
                for (; i <= position.x() - target.x() - 1; ++i) {
                    if (get_board()->occupied[position.x() - i][position.y() - i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()]->isEaten = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            }
        // 二四象限对角线
        } else if (target.x() - position.x() ==  position.y() - target.y()) {
            if (target.x() - position.x() > 0) {
                qDebug() << "right down";
                bool zhangai = false;
                int i = 1;
                for (; i <= target.x() - position.x() - 1; ++i) {
                    if (get_board()->occupied[position.x() + i][position.y() - i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()]->isEaten = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            } else if (target.x() - position.x() < 0) {
                qDebug() << "left upper";
                bool zhangai = false;
                int i = 1;
                for (; i <= position.x() - target.x() - 1; ++i) {
                    if (get_board()->occupied[position.x() - i][position.y() + i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()]->isEaten = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            }
        }
        return true;
    }
    return false;
}

bool Piece::knight_eat(QPoint target) {
    if ((target.x() - position.x() == 1 && target.y() - position.y() == 2) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == 2) ||
            (target.x() - position.x() == 1 && target.y() - position.y() == -2) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == -2) ||
            (target.x() - position.x() == 2 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == -2 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == 2 && target.y() - position.y() == -1) ||
            (target.x() - position.x() == -2 && target.y() - position.y() == -1) ) {
        get_board()->board[target.x()][target.y()]->isEaten = true;
        get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
        get_board()->occupied[position.x()][position.y()] = false;
        get_board()->occupied[target.x()][target.y()] = true;
        get_board()->board[target.x()][target.y()]->position = target;
        return true;
    }
    return false;
}

bool Piece::king_eat(QPoint target) {
    if ((target.x() - position.x() == 1 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == 1 && target.y() - position.y() == 0) ||
            (target.x() - position.x() == 1 && target.y() - position.y() == -1) ||
            (target.x() - position.x() == 0 && target.y() - position.y() == -1) ||
            (target.x() - position.x() == 0 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == 0) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == -1) ) {
        get_board()->board[target.x()][target.y()]->isEaten = true;
        get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
        get_board()->occupied[position.x()][position.y()] = false;
        get_board()->occupied[target.x()][target.y()] = true;
        get_board()->board[target.x()][target.y()]->position = target;
    }
}

Board* Piece::get_board() {
    return current_board;
}

void Piece::move_new(QPoint target) {
    // capture 满足：target可达， target非本方棋子
    if (current_board->highlight[target.x()][target.y()] == true && current_board->occupied[target.x()][target.y()] == true &&
         current_board->board[target.x()][target.y()]->isWhite != isWhite) {
        qDebug() << "capture " << target;
        current_board->board[target.x()][target.y()]->isEaten = true;  //吃
        current_board->occupied[target.x()][target.y()] = true;  // 占领位置
        current_board->board[target.x()][target.y()] = current_board->board[position.x()][position.y()];  //更新对应位置内容
        current_board->board[target.x()][target.y()]->position = target;  //更新坐标
        current_board->occupied[position.x()][position.y()] = false;  // 原先位置置空
        current_board->board[position.x()][position.y()] = new Piece; // 删除
        //
        current_board->set_highlight( current_board->board[target.x()][target.y()]->get_access()); // 新位置仍实现高亮
    // move 满足： target可达 对应位置是空的
    } else if (current_board->highlight[target.x()][target.y()] == true && current_board->occupied[target.x()][target.y()] == false) {
        qDebug() << "move" << target;
        current_board->occupied[target.x()][target.y()] = true; // 占领位置
        current_board->board[target.x()][target.y()] = current_board->board[position.x()][position.y()];  //更新对应位置内容
        current_board->board[target.x()][target.y()]->position = target; //更新坐标
        current_board->occupied[position.x()][position.y()] = false; // 原先位置置空
        current_board->set_highlight( current_board->board[target.x()][target.y()]->get_access()); // 新位置仍实现高亮
        current_board->board[position.x()][position.y()] = new Piece; // 删除
    }
    // 报错
    qDebug() << "movement error!";
}

void Piece::move(QPoint target) {
    if ((target.x() == position.x()) && (target.y() == position.y())) {
        qDebug() << "same point";
        return;
    }
    qDebug() << "begin to move";
    bool success = false;
    if (type == ROOK) {
        qDebug() << "straight move";
        success = straight_move(target);
    } else if (type == BISHOP) {
        qDebug() << "diagonal move";
        success = diagonal_move(target);
    } else if (type == KNIGHT) {
        qDebug() << "knight eat";
        success = knight_move(target);
    } else if (type == QUEEN) {
        qDebug() << "queen move";
        success = straight_move(target) || diagonal_move(target);
    }

    if (!success) {
        qDebug() << type << position  << target << "not success";
    }
}

void Piece::eat(QPoint target) {
    qDebug() << "begin to eat";
    bool success = false;
    if (type == QUEEN || type == ROOK) {
        qDebug() << "straight eat";
        success = straight_eat(target);
    } else if (type == BISHOP || type == QUEEN) {
        qDebug() << "diagonal eat";
        success = diagonal_eat(target);
    } else if (type == KNIGHT) {
        qDebug() << "knight eat";
        success = knight_eat(target);
    }
    if (!success) {
        qDebug() << type << position  << target << "not success";
    }
}

bool Piece::straight_move(QPoint target) {
    //无意义的操作
    if ((target.x() != position.x()) && (target.y() != position.y())) {
        return false;
    }
    qDebug() << "during straight move...";
    if (type == QUEEN || type == ROOK) {
        qDebug() << "right type" << QString::number(type);
        if (target.x() == position.x() && (target.y() != position.y())) { // 同列
            qDebug() << "same column";
                if (target.y() > position.y()) { //上方
                    qDebug() << "move up";
                    bool zhangai = false;
                    int i = position.y() + 1;
                    for (; i <= target.y(); ++i) {
//                        qDebug() << i;
                        if (get_board()->occupied[position.x()][i]) {   //有障碍
                            zhangai = true;
                            break;
                        }
                    }

                    if (zhangai) return false;
                    get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                    get_board()->occupied[position.x()][position.y()] = false;
                    get_board()->occupied[target.x()][target.y()] = true;
                    get_board()->board[target.x()][target.y()]->position = target;
                } else if (target.y() < position.y()) {
                    qDebug() << "move down";
                    bool zhangai = false;
                    int i = position.y() - 1;
                    for (; i >= target.y(); --i) {
//                        qDebug() << i;
                        if (get_board()->occupied[position.x()][i]) {   //有障碍
                            zhangai = true;
                            break;
                        }
                    }
                    if (zhangai) return false;
                    get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                    get_board()->occupied[position.x()][position.y()] = false;
                    get_board()->occupied[target.x()][target.y()] = true;
                    get_board()->board[target.x()][target.y()]->position = target;
                }
        } else if (target.y() == position.y() && (target.x() != position.x())) { //同行
            qDebug() << "same row";
            if (target.x() > position.x()) { //右方
                qDebug() << "move right";
                bool zhangai = false;
                int i = position.x() + 1;
                for (; i <= target.x(); ++i) {
//                    qDebug() << i;
                    if (get_board()->occupied[i][position.y()]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            } else if (target.x() < position.x()) { // 左方
                qDebug() << "move left";
                bool zhangai = false;
                int i = position.x() - 1;
                for (; i >= target.x(); --i) {
//                    qDebug() << i;
                    if (get_board()->occupied[i][position.y()]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            }
        }
        return true;
    }
    return false; //为定义行为
}

bool Piece::diagonal_move(QPoint target) {
    qDebug() << "during straight move...";
    if (type == BISHOP || type == QUEEN) {
        // 一三象限对角线
        if (target.x() - position.x() == target.y() - position.y()) {
            qDebug() << "Line I III";
            // 右上
            if (target.x() - position.x() > 0) {
                qDebug() << "right upper";
                bool zhangai = false;
                int i = 1;
                for (; i <= target.x() - position.x(); ++i) {
                    if (get_board()->occupied[position.x() + i][position.y() + i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            } else if (target.x() - position.x() < 0) {
                qDebug() << "left down";
                bool zhangai = false;
                int i = 1;
                for (; i <= position.x() - target.x(); ++i) {
                    if (get_board()->occupied[position.x() - i][position.y() - i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            }
        // 二四象限对角线
        } else if (target.x() - position.x() ==  position.y() - target.y()) {
            if (target.x() - position.x() > 0) {
                qDebug() << "right down";
                bool zhangai = false;
                int i = 1;
                for (; i <= target.x() - position.x(); ++i) {
                    if (get_board()->occupied[position.x() + i][position.y() - i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            } else if (target.x() - position.x() < 0) {
                qDebug() << "left upper";
                bool zhangai = false;
                int i = 1;
                for (; i <= position.x() - target.x(); ++i) {
                    if (get_board()->occupied[position.x() - i][position.y() + i]) {   //有障碍
                        zhangai = true;
                        break;
                    }
                }
                if (zhangai) return false;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()]->position = target;
            }
        }
        return true;
    }
    return false;
}

bool Piece::knight_move(QPoint target) {
    if ((target.x() - position.x() == 1 && target.y() - position.y() == 2) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == 2) ||
            (target.x() - position.x() == 1 && target.y() - position.y() == -2) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == -2) ||
            (target.x() - position.x() == 2 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == -2 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == 2 && target.y() - position.y() == -1) ||
            (target.x() - position.x() == -2 && target.y() - position.y() == -1) ) {
        get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
        get_board()->occupied[position.x()][position.y()] = false;
        get_board()->occupied[target.x()][target.y()] = true;
        get_board()->board[target.x()][target.y()]->position = target;
    }
}

bool Piece::king_move(QPoint target) {
    if ((target.x() - position.x() == 1 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == 1 && target.y() - position.y() == 0) ||
            (target.x() - position.x() == 1 && target.y() - position.y() == -1) ||
            (target.x() - position.x() == 0 && target.y() - position.y() == -1) ||
            (target.x() - position.x() == 0 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == 1) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == 0) ||
            (target.x() - position.x() == -1 && target.y() - position.y() == -1) ) {
        get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()];
        get_board()->occupied[position.x()][position.y()] = false;
        get_board()->occupied[target.x()][target.y()] = true;
        get_board()->board[target.x()][target.y()]->position = target;
    }
}

void Piece::rook_command(QPoint target) {
    //move + eat
    /*
    if ((target.x() != position.x()) && (target.y() != position.y())) {
        return;
    } else if (target.x() == position.x() && (target.y() != position.x())) { // 同列
        if (target.y() > position.y()) { //上方
            bool zhangai = false;
            bool duifang = false;
            int i = position.y() + 1;
            for (; i <= target.y(); ++i) {
                if (get_board()->occupied[position.x()][i]) {   //有障碍
                    zhangai = true;
                    if (get_board()->board[position.x()][i].isWhite != isWhite) duifang = true;
                    break;
                }
            }
            if (zhangai && duifang) {  //吃对方棋
                get_board()->board[position.x()][i].isEaten = true;
                get_board()->board[position.x()][i] = get_board()->board[position.x()][position.y()]; //修改目标格子内的piece
                get_board()->board[position.x()][i].position = QPoint(position.x(), i);  // 修改目标格子内的piece的坐标
                get_board()->occupied[position.x()][position.y()] = false;
            } else if (!zhangai) {
                get_board()->occupied[position.x()][position.y()] = false;
                get_board()->occupied[target.x()][target.y()] = true;
                get_board()->board[target.x()][target.y()] = get_board()->board[position.x()][position.y()]; //修改目标格子内的piece
                get_board()->board[target.x()][target.y()].position = QPoint(target.x(), target.y()); // 修改目标格子内的piece的坐标
            }
        }
    }
    */
}

Board::Board() {
    for (int i = 0; i < 9; ++i) {
        for (int j = 0; j < 9; ++j) {
            Piece* p = new Piece;
            occupied[i][j] = false;
            highlight[i][j] = false;
            p->current_board = this;
            board[i][j] = p;
            if (board[i][j]->current_board == nullptr) {
                qDebug() << "this is a nullptr";
            } else {
//                qDebug() << "this is not a nullptr";
            }
        }
    }
}

void Board::set_highlight(QVector<QPoint> access) {
    clear_highlight();
    for (auto& p: access) {
        highlight[p.x()][p.y()] = true;
    }
}

void Board::clear_highlight() {
    for (int i = 1; i <= 8; ++i) {
        for (int j = 1; j <= 8; ++j) {
            highlight[i][j] = false;
        }
    }
}

void Board::load_board_from_string(QString& info) {
    int cnt = 0;
    bool whitemode = true;
    auto set_pawn =[&](QStringList para, bool w) {
        int times = para[1].toInt();
        for (int i = 2; i < times + 2; ++i) {
            Piece* p = new Piece(para[0], para[i]);
            p->current_board = this;
            QPoint posi = p->position;
            if (!w)  p->isWhite = false;
            qDebug() << p->isWhite << p->position;
            board[posi.x()][posi.y()] = p;
            occupied[posi.x()][posi.y()] = true;
            cnt++;
        };
    };

    for (auto& line: info.split("\n")) {
        auto temp = line.split(" ");
        qDebug() << temp;
        if(temp[0] == "white") {
            whitemode = true;
        } else if (temp[0] == "black" ) {
            whitemode = false;
        } else if (temp[0] == "king" || temp[0] == "queen" ||  temp[0] == "bishop" ||
                   temp[0] == "knight" ||  temp[0] == "rook" ||  temp[0] == "pawn") {
            set_pawn(temp, whitemode);
        }
    }
    qDebug() << cnt;
}

void Board::clear_all_piece() {
    clear_highlight();
    for (int i = 1; i <=8; ++i) {
        for (int j = 1; j <= 8; ++j) {
            occupied[i][j] = false;
            board[i][j] = new Piece;
        }
    }
}

void Board::init() {
    clear_all_piece();
    auto filename = QFileDialog::getOpenFileName(nullptr, "Open", "/Users/chenwei/Desktop/week8/chess/", "*.txt");
    if (!filename.isEmpty()) {
        QFile f(filename);
        if (f.open(QIODevice::ReadOnly | QFile::Text)) {
            QString info = f.readAll();
            qDebug() << info;
            load_board_from_string(info);
        }
    }
}
