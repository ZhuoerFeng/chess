#ifndef BOARD_H
#define BOARD_H

#include <QString>
#include <QPoint>


enum PawnMove {NO_MOVE, ONE_MOVE, TWO_MOVE};
enum PieceType {NO_TYPE, PAWN, ROOK, KNIGHT, BISHOP, QUEEN, KING};

class Board;

class Piece {
public:
    Piece();
    Piece(QString& name, QString& place);
    ~Piece();
    PieceType type;
    PawnMove first_move = NO_MOVE;
    QPoint position;
    bool isWhite = true;
    bool isEaten = false;
    bool isSelected = false;
//    bool isMovable();
//    bool isSafe();

    QVector<QPoint> get_access();

    void do_command(QPoint target);

    Board* current_board = nullptr;
    Board* get_board();

    void move_new(QPoint target);

    void move(QPoint target);
    void eat(QPoint target);

    bool straight_move(QPoint target);
    bool diagonal_move(QPoint target);
    bool knight_move(QPoint target);
    bool king_move(QPoint target);

    bool straight_eat(QPoint target);
    bool diagonal_eat(QPoint target);
    bool knight_eat(QPoint target);
    bool king_eat(QPoint target);


//    void pawn_command(QPoint target);
    void rook_command(QPoint target);
//    void knight_command(QPoint target);
//    void bishop_command(QPoint target);
//    void queen_command(QPoint target);
//    void king_command(QPoint target);

};

class Board {
public:
    Board();
    Piece* board[9][9];
    bool occupied[9][9];
    bool highlight[9][9];
    void set_highlight(QVector<QPoint>);
    void clear_highlight();
    void clear_all_piece();

    void load_board_from_string(QString& info);
    void init();

};


#endif // BOARD_H
