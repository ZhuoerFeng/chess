#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPainter>
#include <QString>
#include <QPoint>
#include <QMouseEvent>
#include "board.h"

enum GameTurn {WHITE_TURN, BLACK_TURN};

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    void paintEvent(QPaintEvent* event);
    void drawBoard();
    void drawPiece(Piece* p);
    void drawHighlight();
    void mousePressEvent(QMouseEvent* ev);

    GameTurn turn = WHITE_TURN;
    bool isBegin = false;
//    void isEnd();


    QPoint getToggled();
    void setToggled(QPoint);

    Board* board;

    ~MainWindow();

private slots:
    void on_actionNew_triggered();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
