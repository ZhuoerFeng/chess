#include "createclient.h"
#include "ui_createclient.h"
#include <QMessageBox>

CreateClient::CreateClient(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateClient)
{
    ui->setupUi(this);
}

CreateClient::~CreateClient()
{
    delete ui;
}

void CreateClient::connectHost()
{
    qDebug() << "connect to host";
    this->readWriteSocket = new QTcpSocket;
    waiting = true;
    ui->information->setText("Waiting to connect.");


    QObject::connect(this->readWriteSocket,&QTcpSocket::readyRead, [=]() {
//        transmit() << "hello";
        waiting = false;
        ui->information->setText("Connected");
        QMessageBox::information(this, "Success", "You have connected to a host. Please wait for the game start.",
                                 QMessageBox::Ok);
        this->hide();
        recvMessage();
    });


    this->readWriteSocket->connectToHost(QHostAddress::LocalHost,8888);
    ui->lineEditPort->setText("8888");
    QMessageBox::information(this, "Connect", "ready for connection", QMessageBox::Ok);

}

void CreateClient::recvMessage()
{
    qDebug() << "fuck client!!!!";
   emit data_ready();
}


void CreateClient::on_pushButtonOK_clicked()
{
    connectHost();
    ui->pushButtonOK->setEnabled(false);
    ui->pushButtonCancel->setEnabled(true);
    ui->lineEditIP->setEnabled(false);
    ui->lineEditPort->setEnabled(false);
    active = true;
}

void CreateClient::on_pushButtonCancel_clicked()
{
    if (active) {
        active = false;
        ui->pushButtonOK->setEnabled(true);
        ui->pushButtonCancel->setEnabled(true);
        ui->lineEditIP->setEnabled(true);
        ui->lineEditPort->setEnabled(true);
    } else {

    }
}

QTextStream& CreateClient::transmit() {
    static QTextStream t(this->readWriteSocket);
    return t;
}
