#include "createserver.h"
#include "ui_createserver.h"
#include <QMessageBox>

CreateServer::CreateServer(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::CreateServer)
{
    ui->setupUi(this);
}

CreateServer::~CreateServer()
{
    delete ui;
}

void CreateServer::initServer()
{
    this->listenSocket =new QTcpServer;

    QObject::connect(this->listenSocket,SIGNAL(newConnection()),this,SLOT(acceptConnection()));
    this->listenSocket->listen(QHostAddress::Any,8888);
    ui->lineEditIP->setText("127.0.0.1");
    ui->lineEditPort->setText("8888");
    QMessageBox::information(this, "Start", "You have start a host. Please wait for client.",
                                           QMessageBox::Ok);
    ui->information->setText("waiting for client");

}

void CreateServer::acceptConnection()
{
    qDebug() << "server ac";
    waiting = true;
    this->readWriteSocket =this->listenSocket->nextPendingConnection();

    transmit() << "hello" << endl;

//    QObject::connect(this->readWriteSocket,&QTcpSocket::readyRead, [=]() {

        waiting = false;
        ui->pushButtonOK->setEnabled(true);
        ui->pushButtonCancel->setEnabled(true);
        ui->lineEditIP->setEnabled(true);
        ui->lineEditPort->setEnabled(true);
        ui->information->setText("Connected");
        QMessageBox::information(this, "Success", "You have connected to a client. Please wait start the game.",
                                 QMessageBox::Ok);
        this->hide();
        recvMessage();
//    });

}


void CreateServer::recvMessage()
{
    qDebug() << "fuck server!!!";
    emit data_ready();
}

void CreateServer::on_pushButtonOK_clicked()
{
    initServer();
    ui->pushButtonOK->setEnabled(false);
    ui->pushButtonCancel->setEnabled(true);
    ui->lineEditIP->setEnabled(false);
    ui->lineEditPort->setEnabled(false);
    active = true;
}

void CreateServer::on_pushButtonCancel_clicked()
{
    if (active) {
        active = false;
        ui->pushButtonOK->setEnabled(true);
        ui->pushButtonCancel->setEnabled(true);
        ui->lineEditIP->setEnabled(true);
        ui->lineEditPort->setEnabled(true);
    } else {

    }

}

QTextStream& CreateServer::transmit() {
    static QTextStream t(this->readWriteSocket);
    return t;
}
