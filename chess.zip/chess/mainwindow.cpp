#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QPainter>
#include <QPaintEvent>
#include <QDebug>
#include <string.h>
#include <QStringList>
#include <QFileDialog>
//#include "board.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    board(new Board)
{
    ui->setupUi(this);
    setFixedSize(600, 600);
}

void MainWindow::paintEvent(QPaintEvent* event) {
    drawBoard();
    for (int i = 1; i <= 8; ++i) {
        for (int j = 1; j <= 8; ++j) {
            if (board->occupied[i][j]) {
                drawPiece(board->board[i][j]);
            }
        }
    }
}

void MainWindow::drawBoard() {
    QPainter p(this);
    p.setPen(Qt::NoPen);
    p.setBrush(QColor(210, 180, 140));
    p.drawRect(QRect(QPoint(60, 60), QPoint(540, 540)));



    // (100, 100) ->  (500, 500)
    for (int i = 1; i <= 8; ++i) {
        for (int j = 1; j <= 8; ++j) {
            if ((i + j) % 2 == 0) {
                p.setBrush(QColor(255, 245, 238, 180));
                p.drawRect(QRect(QPoint(50 + j * 50, 50 + i * 50), QPoint(100 + j * 50, 100 + i * 50)));
            } else if ((i + j) % 2 == 1) {
                p.setBrush(QColor(135, 51, 36, 180));
                p.drawRect(QRect(QPoint(50 + j * 50, 50 + i * 50), QPoint(100 + j * 50, 100 + i * 50)));
            }

            if (board->highlight[j][i]) {
                p.setBrush(QColor(135, 206, 235, 1));
                 p.drawRect(QRect(QPoint(50 + j * 50, 50 + (9 - i) * 50), QPoint(100 + j * 50, 100 + (9 - i) * 50)));
                 qDebug() << QPoint(i, j);
            }
        }
    }
    //覆盖问题？？？？
    for (int i = 1; i <= 8; ++i ){
        for (int j = 1; j <= 8 ;++j) {
            if (board->highlight[j][i]) {
                p.setBrush(QColor(135, 206, 235));
                 p.drawRect(QRect(QPoint(50 + j * 50, 50 + (9 - i) * 50), QPoint(100 + j * 50, 100 + (9 - i) * 50)));
                 qDebug() << QPoint(i, j);
            }
        }
    }

    QFont f;
    f.setPointSize(18);
    p.setFont(f);

    p.setPen(QPen(QColor(255, 250, 250), 4));
    p.setBrush(QColor(255, 255, 255));

    for (int i = 1; i <= 8; ++i) {
        p.drawText(QRect(QPoint(60, 550 - i * 50), QPoint(100, 500 - i * 50)), Qt::AlignCenter, QString::number(i));

    }
    for (int i = 1; i<=8; ++i) {
        char c = i + 96;
        p.drawText(QRect(QPoint(50 + i * 50, 500), QPoint(100 + i * 50, 530)), Qt::AlignCenter, QString(c));
    }
    p.setCompositionMode(QPainter::CompositionMode_SourceOver);
}

void MainWindow::drawPiece(Piece* p) {
//    QPixmap pm("/Users/chenwei/Desktop/week8/chess/src/black_bishop.png");
    QPainter gongjuren(this);
    auto paint = [&](QPixmap pm) {
        QPainter gongjuren(this);
        pm = pm.scaled(QSize(40, 40), Qt::KeepAspectRatio);
        int x = p->position.x() * 50 + 55;
        int y = (9 - p->position.y()) * 50 + 55;
        gongjuren.drawPixmap(QRect(QPoint(x, y), QPoint(x, y)+QPoint(40 ,40)), pm);
    };

    if (!p->isEaten) {
        if (getToggled() == p->position)
        {
            int x = p->position.x() * 50 + 65;
            int y = (9 - p->position.y()) * 50 + 65;
            gongjuren.setBrush(QColor(255, 255, 255, 120));
            gongjuren.drawEllipse(QRect(QPoint(x, y), QPoint(x, y)+QPoint(20 ,20)));
        }
        if (p->isWhite) {
            if (p->type == PAWN) {
                QPixmap pm(":/pics/src/white_pawn.png");
                paint(pm);
            } else if (p->type == ROOK) {
                QPixmap pm(":/pics/src/white_rook.png");
                paint(pm);
            } else if (p->type == KNIGHT) {
                QPixmap pm(":/pics/src/white_knight.png");
                paint(pm);
            } else if (p->type == BISHOP) {
                QPixmap pm(":/pics/src/white_bishop.png");
                paint(pm);
            } else if (p->type == QUEEN) {
                QPixmap pm(":/pics/src/white_queen.png");
                paint(pm);
            } else if (p->type == KING) {
                QPixmap pm(":/pics/src/white_king.png");
                paint(pm);
            }
        } else if (!p->isWhite) {
            if (p->type == PAWN) {
                QPixmap pm(":/pics/src/black_pawn.png");
                paint(pm);
            } else if (p->type == ROOK) {
                QPixmap pm(":/pics/src/black_rook.png");
                paint(pm);
            } else if (p->type == KNIGHT) {
                QPixmap pm(":/pics/src/black_knight.png");
                paint(pm);
            } else if (p->type == BISHOP) {
                QPixmap pm(":/pics/src/black_bishop.png");
                paint(pm);
            } else if (p->type == QUEEN) {
                QPixmap pm(":/pics/src/black_queen.png");
                paint(pm);
            } else if (p->type == KING) {
                QPixmap pm(":/pics/src/black_king.png");
                paint(pm);
            }
        }
    }
}

QPoint MainWindow::getToggled() {
    for (int i = 1; i <= 8; ++i) {
        for (int j = 1; j <= 8; ++j) {
            if (board->occupied[i][j] == true) {
                if (board->board[i][j]->isSelected)
                    return QPoint(i, j);
            }
        }
    }
    return  QPoint(0, 0);
}

void MainWindow::setToggled(QPoint p) {
    board->board[getToggled().x()][getToggled().y()]->isSelected = false;
    board->board[p.x()][p.y()]->isSelected = true;
    board->set_highlight(board->board[p.x()][p.y()]->get_access()); // 加高亮
    this->update();
}

void MainWindow::mousePressEvent(QMouseEvent *ev) {
    int x = ev->x() / 50 - 1;
    int y = 10 - ev->y() / 50 ;
    qDebug() << ev->x() << ev->y() <<x << y;
    // 1 判断轮次
    // 2 判断有没有选中棋子 （选中棋子
    // 3 选中的棋子 移动=抓子 （如果键入无效坐标 => 5/6
    // 4 回合结束
    // 5 选中新的 己方棋子
    // 6 取消 已选棋子
    if (x >= 1 && x <= 8 && y >= 1 && y <= 8) {
        //1 没有已选中的棋子 现在是错的
        if (getToggled() == QPoint(0, 0)) {
            qDebug() << "1";
            // 2 若满足条件则选中一个棋子 否则什么也不做
            if (board->occupied[x][y] == true) {
                qDebug() << "2";
                setToggled(QPoint(x, y));
            }
        //3 已经有选中的棋子了
        } else if (getToggled() != QPoint(0, 0)) {
            qDebug() << "3";
            // 4 点击是己方的一个切换命令
            if (board->occupied[x][y] == true && getToggled()!= QPoint(x,y) && board->board[x][y]->isEaten == false &&
                    board->board[x][y]->isWhite == board->board[getToggled().x()][getToggled().y()]->isWhite) {
                qDebug() << "4";
                setToggled(QPoint(x, y));
            // 5 点击是己/对方的一个切换命令 仅供调试
            } else if (board->occupied[x][y] == true && getToggled()!= QPoint(x,y) && board->board[x][y]->isEaten == false &&
                       board->board[x][y]->isWhite != board->board[getToggled().x()][getToggled().y()]->isWhite) {
                   qDebug() << "5";
                   setToggled(QPoint(x, y));
            // 6 只考虑移动操作
            } else {
                qDebug() << "6";
                // 7 是可达区域
                if (board->highlight[x][y]) {
                    qDebug() << "7";
                    board->board[getToggled().x()][getToggled().y()]->move_new(QPoint(x, y));
                // 8 不可达
                } else {
                    qDebug() << "8 not accessible";
                }
            }
        }
    }
    this->update();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_actionNew_triggered()
{
    board->init();
    this->update();
}
